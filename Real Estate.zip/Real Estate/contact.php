<?php
include "./include/header.php";

?>


<br>
<br>

<br>
<br>
<br>




<section id="" class=" " style="    background-color: #1f386e;">
  <br>
  <br>

  <br>
  <div class="container">


    <center>
      <h2 style="color: #fff;">Contact</h2>
    </center>



    <div class="row">

      <div class="col-12 ">
        <iframe class="mb-4 mb-lg-0" src="
          https://maps.google.com/maps?width=600&amp;height=400&amp;hl=en&amp;q=APR Realty, Shankara Road, Bagalya Darshan Shankara Nagar, Sonar Pada, Dombivli East, Dombivli, Maharashtra 421201&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" frameborder="0" style="border:0; width: 100%; height: 384px;
          " allowfullscreen></iframe>
      </div>


    </div>


    <br>

    <div class="row">



      <div class="col-lg-7 col-12 d-flex" style="background: url(./images/loc.jpg); height:500px; background-size: 100% 100%;">








      </div>

      <style>
        .contactd {
          height: 500px;
          display: flex;
          justify-content: center;
          flex-direction: column;
        }

        @media (max-width:540px) {

          .contactd {
            height: auto;
            display: flex;
            justify-content: center;
            flex-direction: column;
          }

        }
      </style>

      <div class="col-lg-5 col-12 contactd">

        <center>
          <h3 class="" style="color: #fff;">Contact now</h3>
        </center>


        <form action="./mail.php" method="post">
          <div class="col-12" style="margin-top: 2rem; padding: 0px 13px;">
            <input type="text" name="name" required placeholder="Name" style="width: 100%; padding: 6px 12px; font-size: 14px; color: #555; background-color: #fff; background-image: none; border: 1px solid #ccc; border-radius: 4px;">
          </div>
          <div class="col-12" style="margin-top: 2rem; padding: 0px 13px;">
            <input type="email" name="email" required placeholder="email" style="width: 100%; padding: 6px 12px; font-size: 14px; color: #555; background-color: #fff; background-image: none; border: 1px solid #ccc; border-radius: 4px;">
          </div>
          <div class="col-12" style="margin-top: 2rem; padding: 0px 13px;">
            <input type="Number" name="number" required placeholder="Number" style="width: 100%; padding: 6px 12px; font-size: 14px;  color: #555; background-color: #fff; background-image: none; border: 1px solid #ccc; border-radius: 4px;">
          </div>

          <div class="col-12" style="margin-top: 2rem; padding: 0px 13px;">
            <textarea name="Message" placeholder="Message" style="width: 100%; padding: 6px 12px; font-size: 14px;  color: #555; background-color: #fff; background-image: none; border: 1px solid #ccc; border-radius: 4px;"></textarea>

          </div>

          <center>
            <button class="btn btn-success" name="Enquiry" style="margin-top: 2rem;">Enquiry</button>
          </center>


        </form>

      </div>


    </div>



  </div>
  <br>
</section>




<?php
include "./include/footer.php";

?>