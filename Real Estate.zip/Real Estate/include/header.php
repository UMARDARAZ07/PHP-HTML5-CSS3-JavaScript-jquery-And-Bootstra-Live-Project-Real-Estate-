<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>APR Realty Emerald</title>
  <meta name="description" content="APR Emerald is located in Dombivli East, 10 Minutes from Dombivli Station. The Project Offers Luxurious Lifestyle with world class Amenities.">
  
  <meta name = "keywords" content="1 BHK in Dombivli, Residential Project in Dombivli, Property in Dombivli
, Affordable housing in Dombivli,2 BHK in Dombivli,Flats in Dombivli,Apartments in Dombivli,Ready Possession property in Dombivli,Under Construction property in Dombivli,apartment in mumbai,flat in dombivli," >  
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <!-- Favicons
    ================================================== -->
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="img/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

  <!-- Bootstrap -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">
  
  <!-- Stylesheet
    ================================================== -->
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/nivo-lightbox/nivo-lightbox.css">
  <link rel="stylesheet" type="text/css" href="css/nivo-lightbox/default.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
  <!-- aos -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 




</head>
<style>
  .navcol {
    padding: 6px 0px;
    display: flex;
    flex-direction: column;

  }

  .location {
    margin-top: -31px;

    position: relative;
  }

  .btn1234 {

    float: right;
  }

  @media(max-width:540px) {
    .location {
      display: none;
    }

    .navcol {
      margin-top: 50px;
      background-color: white;
      padding: 0px;
      display: none;
    }

    .navbar12 {
      background-color: white;

    }

    .btn1234 {
      display: none;
    }
    .navbar-nav {
    margin: 7.5px 0px;
}

  }
</style>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
  <!-- Navigation
    ==========================================-->

  <nav id="menu" class="navbar navbar-default navbar-fixed-top p-0 my-3" style="height: 130px; ">
    <div class="container" style="height: 100%;">

      <div class="navbar-header">
      <!-- <a type="button" class="btn btn-primary btn12 ">9892544519</a> -->
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" onclick="navhow()"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a class="navbar-brand page-scroll" href="./index.php">
          <img src="./images/aprslogo.png" alt="" style="margin-top: -28px; height:120px;">

        </a>

      </div>


      <div class="collapse navbar-collapse navcol" id="bs-example-navbar-collapse-1">

        <ul class="nav navbar-nav navbar-right navbar12">
          <li><a href="./index.php" class="page-scroll">Home</a></li>
          <li><a href="./about.php" class="page-scroll">About</a></li>
          <li><a href="./amenities.php" class="page-scroll">Amenities</a></li>
          <li><a href="./configuration.php" class="page-scroll">Configuration</a></li>

          <li><a href="./contact.php" class="page-scroll">Contact</a></li>
        </ul>
        <br>


      </div>

    </div>
    <div class="container">
      <div class="col-12">
        <ul class="  location">
          <a type="button" class="btn btn-primary btn1234 ">9892544519</a>



        </ul>
      </div>
    </div>
  </nav>
