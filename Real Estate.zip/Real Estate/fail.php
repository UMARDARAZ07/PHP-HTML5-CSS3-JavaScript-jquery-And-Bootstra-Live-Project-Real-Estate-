<?php

echo   "<script>
alert('Error while sending Email.')
window.location.href='index.php'
</script>";

?>