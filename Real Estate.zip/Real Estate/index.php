<?php
include "./include/header.php";
?>
<!-- Header -->
<!-- <header id="header">
  <div class="intro">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 intro-text">
            <h1>Home Construction<br>
              & Remodeling</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at.</p>
            <a href="#about" class="btn btn-custom btn-lg page-scroll">Learn More</a> </div>
        </div>
      </div>
    </div>
  </div>
</header> -->
<style>
  .mbbanner {
    display: none;
  }

  @media (max-width:540px) {
    .pcslider {
      display: none;
    }

    .mbbanner {
      display: block;
    }
  }
</style>

<br>
<br>




<div class="container-fluid pcslider">

  <div id="myCarousel" class="carousel slide" data-ride="carousel">

    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>


    <div class="carousel-inner">

      <div class="item active ">
        <br>
        <br>
        <br>
        <br>

        <img class="" src="./images/banner1 (1).jpeg" alt="Flats in Dombivli" style="width:100%; height: 600px;">
        <!-- <img src="./images/mbbanner1.jpg"alt="Houses for sale" style="width:100%;"> -->
      </div>

      <div class="item ">
        <br>
        <br>
        <br>
        <br>
        <img src="./images/Pravin BHK 2-3  (1).png" class="" alt="Apartments in Dombivli" style="width:100%; height: 600px;">

        <!-- <img class="mbbanner" src="./images/mbbanner2.jpg"alt="Houses for sale" style="width:100%;"> -->

      </div>

      <div class="item ">
        <br>
        <br>
        <br>
        <br>
        <img src="./images/banner1 (2).jpeg" class="pcslider" alt="Property in Dombivli" style="width:100%; height: 600px;">


      </div>




      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
      </a>

    </div>
  </div>

</div>











<style>
  .carousel-caption {
    font-size: 12px;
    font-style: italic;
    font-weight: bold;
    /* display: none;  remove comment to hide captions */
  }

  .carousel-control {
    text-shadow: 0;
  }

  .carousel-control.left {
    background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, .0001) 100%);
    background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, 0) 100%);
    background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0)), to(rgba(0, 0, 0, 00001)));
    background-image: linear-gradient(to right, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, 0) 100%) !important;
  }

  .carousel-control.right {
    background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, .0001) 100%);
    background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, 0) 100%);
    background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0)), to(rgba(0, 0, 0, 00001)));
    background-image: linear-gradient(to right, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, 0) 100%) !important;
  }
</style>




<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">

    <!-- <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li> -->
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner  mbbanner" role="listbox">
    <div class="item active">
      <br>
      <br>
      <br>
      <br>

      <img src="./images/1.png" width="100%" style="margin-top: 10px;"  alt="Property in Dombivli">
      <!-- <div class="carousel-caption">
        <h3>First Slide</h3>
        <p>Caption goes here<br></p>
      </div> -->
    </div>
    <div class="item">
      <br>
      <br>
      <br>
      <br>
      <img src="./images/2.png" width="100%" style="margin-top: 10px;" alt="Flats in Dombivli">
      <!-- <div class="carousel-caption">
        <h3>Second slide</h3>
        <p>Caption goes here</p>
      </div> -->
    </div>



  </div>

  <!-- Controls -->
  <a class="left carousel-control mbbanner" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left mbbanner" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control mbbanner" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right " aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</div>

</div>

<style>
  .md {
    padding: 10px 22px;
  }

  .md2 {
    padding: 10px 22px;
  }

  @media (max-width:540px) {
    .md {
      padding: 10px 25px;
    }

    .md2 {
      padding: 10px 18px;
    }
  }
</style>










<!-- Get Touch Section -->
<div id="get-touch">
  <div class="container">
    <div class="row">
      <div class="col-12 col-md-offset-1 " data-aos="fade-down">
        <center class="mt-5">
          <h1 class="mt-5" style="    font-size: 24px;">About Apr Reality</h1>
        </center>
        <center>
          <p>
            APR Emerald is spread across 2.5 Acres land parcel in Shankara nagar, Dombivli East. The project offer mix of both worlds World class amenities and Excellent Connectivity.

          </p>
        </center>
        <center>
          <p>
            Within the gated community of the project there is an inbuilt Swami Samarth Math, on top of that it proposed to offer luxurious with world class amenities of Club House with Swimming Pool, Gymnasium, Senior Citizen Sitting Area, Yoga & Meditation Centre, Kids Play Area, Garden etc.

          </p>
        </center>


        <center>
          <p>
            The project is centrally located with International schools, Engineering College, Pharmacy College, Bank, Upcoming Metro station etc.
          </p>
        </center>
        <div class="" style="    display: flex;    flex-wrap: wrap;    justify-content: center;">
          <div class="col-md-5 col-12" style="display: flex;  margin-top: 15px; ">
            <div class="col-6 md" style="border: 2px solid #102246;   ">
              <center>
                <h3 style="font-weight: 800;"> 1 BHK </h3>
                <p>
                  <b>
                    (466 Sq.Ft)
                  </b>

                </p>
              </center>
            </div>
            <div class="col-6 md" style="border: 2px solid #102246; background-color: #BFBCCD;">

              <center>
                <h3 style="font-weight: 800; color:#021331;">
                  ₹ 37 LACS*
                </h3>
                <p style=" color:#021331;">
                  <b>
                    All Inclusive
                  </b>

                </p>
              </center>
            </div>
          </div>
          <div class="col-md-5 col-12" style="display: flex;  margin-top: 15px; ">
            <div class="col-6 md" style="border: 2px solid #102246;   ">
              <center>
                <h3 style="font-weight: 800;"> 2 BHK </h3>
                <p>
                  <b>
                    (847 Sq.Ft)
                  </b>

                </p>
              </center>
            </div>
            <div class="col-6 md" style="border: 2px solid #102246; background-color: #BFBCCD;">

              <center>
                <h3 style="font-weight: 800; color:#021331;">
                  ₹ 71 LACS*
                </h3>
                <p style=" color:#021331;">
                  <b>
                    All Inclusive
                  </b>

                </p>
              </center>
            </div>
          </div>
          <div class="col-md-5 col-12" style="display: flex;     margin-top: 15px;">
            <div class="col-6 md2" style="border: 2px solid #102246;  ">
              <center>
                <h3 style="font-weight: 800; "> 3 BHK </h3>
                <p>
                  <b>
                    (920 Sq.Ft)
                  </b>

                </p>
              </center>
            </div>
            <div class="col-6 md2 " style="border: 2px solid #102246;      background-color: #BFBCCD;">

              <center>
                <h3 style="font-weight: 800; color:#021331;">
                  ₹ 76.50 LACS*
                </h3>
                <p style=" color:#021331;">
                  <b>
                    All Inclusive
                  </b>
                </p>
              </center>
            </div>



          </div>

        </div>
      </div>
      <!-- <div class="col-xs-12 col-md-4 text-center"><a href="#contact" class="btn btn-custom btn-lg page-scroll">Free Estimate</a></div> -->
    </div>
  </div>
</div>
<!-- About Section -->
<div id="about" style="background-color: #1f386e;">
  <center>
    <h3 style="color: #fff;"> Projects Proceeding :</h3>
  </center>
  <div class="container">
    <div class="d-flex flex-wrap">
      <div class=" col-md-6 col-12 d-flex justify-content-center" data-aos="fade-up">

        <!-- <h2>Carousel Example</h2> -->
        <div id="myCarousel" class="carousel slide " data-ride="carousel">
          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner">

            <div class="item active">
              <img src="./images/apre.jpg" alt="Ready Possession property in Dombivli" style="width:100%; height: 400px;">
              <div class="carousel-caption">

                <p>
                  <b>
                    APR Emerald
                  </b>
                </p>
              </div>
            </div>

            <div class="item">
              <img src="./images/adishakti.jpg" alt="Adhishakti  project" style="width:100%; height: 400px;">
              <div class="carousel-caption">

                <p>
                  <b>
                    Adishakti
                  </b>
                </p>
              </div>

            </div>

            <div class="item">
              <img src="./images/emerald.jpg" alt="Under Construction Property in Dombivl" style="width:100%; height:400px;">
              <div class="carousel-caption">

                <p>
                  <b>
                    Emerald Pacific
                  </b>
                </p>
              </div>
            </div>

          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>







      <div class="col-md-6 col-12" data-aos="fade-up">

        <div class="about-text ">
          <p style="color: #fff;">
            <b>
              Open Floor Plans:
            </b>Step into spacious, open floor plans that seamlessly integrate the living, dining, and kitchen areas. This design maximizes the use of space, enhances natural light flow, and promotes a modern and airy ambiance, perfect for both relaxation and entertainment.
          </p>

          <p style="color: #fff;">
            <b>
              Modern Kitchen:
            </b> Discover a well-appointed kitchen that combines style and functionality. Equipped with ample storage space, and efficient layouts, the kitchen is a hub for culinary creativity and convenience.

          </p>

          <p style="color: #fff;">
            <b>
              Ample Storage:
            </b> Experience the ease of organized living with abundant storage options. From walk-in closets in bedrooms to built-in shelving units, apartments are designed to accommodate your belongings while maintaining a clutter-free environment.
          </p>



          <!-- <center><button class="btn btn-primary">Book Know</button></center> -->
        </div>


      </div>






    </div>
  </div>
</div>



<style>
  .btn12 {
    margin-top: -26px;
    position: absolute;
    margin-left: -64px
  }

  .btn12:hover {
    background-color: #1f386e;
    border-color: #1f386e;
  }

  .btn123 {
    margin-top: -26px;
    position: absolute;
    margin-left: -112px;
  }

  .btn123:hover {
    background-color: #1f386e;
    border-color: #1f386e;
  }

  @media (max-width:540px) {
    .btn12 {
      margin-top: -29px;
      position: absolute;
      margin-left: 72px;
      display: block;
      margin-bottom: 0px;
    }
  }
</style>


<!-- Services Section -->
<div id="services" class="py-5">
  <div class="container">
    <div class="">
      <center>
        <h2>Amenities </h2>
        <p class="pt-0">
          <b> Take You a Step Closer to a Satisfying Lifestyle </b>
        </p>
      </center>
    </div>
    <div class="row">
      <div class="col-md-4" data-aos="zoom-in" style="    margin-top: 17px;">
        <div class="service-media"> <img src="./images/s2.png" alt="SWIMMING POOL"> </div>
        <div class="service-desc d-flex justify-content-center">
          <center>
            <button type="button" class="btn btn-primary btn12" style="">SWIMMING POOL</button>
          </center>
          <h3></h3>

        </div>
      </div>
      <div class="col-md-4" data-aos="zoom-in" style="    margin-top: 17px;">
        <div class="service-media"> <img src="./images/s5.jpeg" alt="CHILDREN’S PLAY AREA"> </div>
        <div class="service-desc  d-flex justify-content-center">

          <center>
            <button type="button" class="btn btn-primary btn12">CHILDREN’S PLAY AREA</button>
          </center>

        </div>
      </div>
      <div class="col-md-4" data-aos="zoom-in" style="    margin-top: 17px;">
        <div class="service-media"> <img src="./images/s4.png" alt="GYMNASIUM"> </div>
        <div class="service-desc  d-flex justify-content-center">

          <center>
            <button type="button" class="btn btn-primary btn12">GYMNASIUM</button>
          </center>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4" data-aos="zoom-in" style="    margin-top: 17px;">
        <div class="service-media"> <img src="./images/s7.png" alt="SENIOR CITIZEN SITTING AREA"> </div>
        <div class="service-desc  d-flex justify-content-center">

          <center>
            <button type="button" class="btn btn-primary btn123">SENIOR CITIZEN SITTING AREA</button>
          </center>
        </div>
      </div>
      <div class="col-md-4" data-aos="zoom-in" style="    margin-top: 17px;">
        <div class="service-media"> <img src="./images/s3.png" alt="INDOOR GAMES"> </div>
        <div class="service-desc  d-flex justify-content-center">

          <center>
            <button type="button" class="btn btn-primary btn12">INDOOR GAMES</button>
          </center>
        </div>
      </div>
      <div class="col-md-4" data-aos="zoom-in" style="    margin-top: 17px;">
        <div class="service-media"> <img src="./images/img12.jpg" alt="Grand Entrance Gate "> </div>
        <div class="service-desc  d-flex justify-content-center">

          <center>
            <button type="button" class="btn btn-primary btn12">Grand Entrance Gate </button>
          </center>
        </div>
      </div>

    </div>
  </div>
</div>

<style>
  @media (max-width:540px) {
    .loc {
      display: none;
    }
  }
</style>
<section class="pt-2 loc">
  <center>
    <h2>Location</h2>
  </center>

  <div class="container">
    <div style="width: 100%; height: 700px; background: url(./images/loc.jpg); background-size: 100% 100%;" data-aos="zoom-in">

    </div>
  </div>
</section>

<br>




<!-- Gallery Section -->
<div id="portfolio">
  <div class="container">
    <div class="">
      <center>
        <h2>Gallery</h2>
      </center>
    </div>
    <div class="row">
      <div class="portfolio-items">
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="" title="Project Title" data-lightbox-gallery="gallery1">

                <img src="./images/1.jpg" class="img-responsive" alt="Project Title">
              </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="" title="Project Title" data-lightbox-gallery="gallery1">

                <img src="./images/2.jpg" class="img-responsive" alt="Project Title">
              </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="" title="Project Title" data-lightbox-gallery="gallery1">

                <img src="./images/3.jpg" class="img-responsive" alt="Project Title">
              </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="" title="Project Title" data-lightbox-gallery="gallery1">

                <img src="./images/4.jpg" class="img-responsive" alt="Project Title">
              </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="" title="Project Title" data-lightbox-gallery="gallery1">

                <img src="./images/6 (2).jpg" class="img-responsive" alt="Project Title">
              </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="" title="Project Title" data-lightbox-gallery="gallery1">

                <img src="images/img82.jpg" class="img-responsive" alt="Project Title">
              </a> </div>
          </div>


        </div>
        <div class="col-sm-6 col-md-4 col-lg-4">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="" title="Project Title" data-lightbox-gallery="gallery1">

                <img src="images/img2.jpg" class="img-responsive" alt="Project Title">
              </a> </div>
          </div>


        </div>



      </div>
    </div>
  </div>
</div>
</div>






<?php
include "./include/footer.php";
?>


<script>
  $(".fg").swipe({
    swipe: function(
      event,
      direction,
      distance,
      duration,
      fingerCount,
      fingerData
    ) {
      if (direction == "left") $(this).carousel("next");
      if (direction == "right") $(this).carousel("prev");
    },
    allowPageScroll: "vertical"
  });

  $(".fg").swipe({
    swipe: function(
      event,
      direction,
      distance,
      duration,
      fingerCount,
      fingerData
    ) {
      if (direction == "left") $(this).carousel("next");
      if (direction == "right") $(this).carousel("prev");
    },
    allowPageScroll: "vertical"
  });
</script>