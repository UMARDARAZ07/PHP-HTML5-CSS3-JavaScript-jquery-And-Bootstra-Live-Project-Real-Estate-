<?php
include "./include/header.php";

?>

<br>
<br>
<br>

<br>
<br>


<style>
  .btn12:hover {
    transition: 1s background-color;
    background-color: #1f386e;
    border-color: #1f386e;
  }
</style>



<section class="pt-2" style="background-color: #1f386e;">
  <div class="container">

    <br>
    <br>
    <center>
      <h1 style="color:#fff;     font-size: 20px;">
        APR Emerald offers luxurious lifestyle with world class amenities,

      </h1>


      <p style="color:#fff">
        The project comprises of Full Operational Club House with Swimming Pool, indoor Games, Fully equipped Gym, Kids Play Area, Jogging & Cycling Track, Garden, Senior Citizen Sitting Area etc.
      </p>

    </center>


    <div id="services" style="padding: 10px;">
      <div class="container">
        <div class="">
          <center>

            <p class="pt-0" style="color:#fff">
              <b> Take You a Step Closer to a Satisfying Lifestyle </b>
            </p>
          </center>
        </div>
        <div class="row">
          <div class="col-md-4" data-aos="zoom-in">
            <div class="service-media"> <img src="./images/s2.png" alt="SWIMMING POOL"> </div>
            <div class="service-desc d-flex justify-content-center">
              <center>
                <button type="button" class="btn btn-primary btn12" style="margin-top: -26px; position: absolute; margin-left:-64px">SWIMMING POOL</button>
              </center>
              <h3></h3>

            </div>
          </div>
          <div class="col-md-4" data-aos="zoom-in">
            <div class="service-media"> <img src="./images/s5.jpeg" alt="CHILDREN’S PLAY AREA"> </div>
            <div class="service-desc  d-flex justify-content-center">

              <center>
                <button type="button" class="btn btn-primary btn12" style="margin-top: -26px; position: absolute; margin-left:-84px">CHILDREN’S PLAY AREA</button>
              </center>

            </div>
          </div>
          <div class="col-md-4" data-aos="zoom-in">
            <div class="service-media"> <img src="./images/s4.png" alt="GYMNASIUM "> </div>
            <div class="service-desc  d-flex justify-content-center">

              <center>
                <button type="button" class="btn btn-primary btn12" style="margin-top: -26px; position: absolute; margin-left:-64px">GYMNASIUM</button>
              </center>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4" data-aos="zoom-in">
            <div class="service-media"> <img src="./images/s7.png" alt="SENIOR CITIZEN SITTING AREA"> </div>
            <div class="service-desc  d-flex justify-content-center">

              <center>
                <button type="button" class="btn btn-primary btn12" style="margin-top: -26px; position: absolute; margin-left:-119px">SENIOR CITIZEN SITTING AREA</button>
              </center>
            </div>
          </div>
          <div class="col-md-4" data-aos="zoom-in">
            <div class="service-media"> <img src="./images/s3.png" alt="INDOOR GAMES"> </div>
            <div class="service-desc  d-flex justify-content-center">

              <center>
                <button type="button" class="btn btn-primary btn12" style="margin-top: -26px; position: absolute; margin-left:-64px">INDOOR GAMES</button>
              </center>
            </div>
          </div>
          <div class="col-md-4" data-aos="zoom-in">
            <div class="service-media"> <img src="./images/img12.jpg" alt="Grand Entrance Gate"> </div>
            <div class="service-desc  d-flex justify-content-center">

              <center>
                <button type="button" class="btn btn-primary btn12" style="margin-top: -26px; position: absolute; margin-left:-64px">Grand Entrance Gate </button>
              </center>
            </div>
          </div>

        </div>
      </div>
    </div>



  </div>


  </div>
  </div>
  <br>
  <br>
</section>



<?php
include "./include/footer.php";

?>