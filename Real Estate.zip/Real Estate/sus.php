<?php

echo "<script>
alert('Email sent successfully')
window.location.href='index.php'
</script>";

?>