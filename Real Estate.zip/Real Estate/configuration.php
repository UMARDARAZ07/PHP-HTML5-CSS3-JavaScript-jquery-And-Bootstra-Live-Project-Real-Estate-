<?php
include "./include/header.php";

?>

<br>
<br>
<br>

<br>
<br>

<br>

<style>
    .bhkimg {
        height: 500px;
        width: 100%;
    }


    .bhk {
        height: 500px;
        padding: 30px;
        display: flex;
        flex-direction: column;
        justify-content: center;

    }

    @media (max-width:540px) {
        .bhk {
            height: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;

        }

        .bhkimg {
            height: 400px;
            width: 100%;
        }

    }
</style>

<div id="services" class="py-5" style="    background-color: #1f386e;     padding: 45px 0px;">
    <div class="container">
       
<center>
    <h1 style="color:#fff;    font-size: 20px;">
    CONFIGURATION
    </h1>
</center>
 <center>  <p style="color:#fff; font-weight:500;">APR Realty believes in delivering affordable luxury to its customers, All 1 BHKs comes with Masterbedroom ,Bigger Carpet , Spacious Balconies , Separate Dry Balcony  and specius in size. All 2 BHKs comes with Separate Pooja room ,Vastu Certified , Spacious Balconies , Separate Dry Balcony  and specius in size  . All 3 BHKs comes with Bigger Carpet , Separate Pooja room , Spacious Balconies , Vastu Certified
    and specius in size with affordable price :</p>
    </center> 


        <div class="row " style="margin-top: 2rem; 
    box-shadow: 0 0 30px rgba(114, 120, 131, 0.6); padding:15px 0px;      background-color: #fff;">
            <center>
                <h2>1 BHK - CARPET AREA (466 SQ.FT)</h2>
            </center>
            <div class="col-md-7" data-aos="zoom-in">
                <img src="./images/bhks.png"  class="img-fluid bhkimg" alt="1 BHK in Dombivli">
            </div>
            <div class="col-12 col-md-5 bhk " data-aos="zoom-in">

            

                <h3 style=" font-size:25px; color:#03a9f4; ">
                    <b>
                        37 Lacs All Inclusive

                    </b>
                </h3>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Bigger Carpet

                </p>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Master Bedroom

                </p>

                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Spacious Balconies

                </p>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Separate Dry Balcony

                </p>


                <center> <a href="https://wa.me/9892544519?text=Hello,

I am interested to know more about APR Emerald.

Please share the project details and connect me on the same number" target="_blank" type="button" class="btn btn-success" style="padding: 3px 3rem;"><b>Contact Now </b> </a> </center>
            </div>

        </div>


        <div class="row mt-3" style="margin-top: 2rem; 
    box-shadow: 0 0 30px rgba(114, 120, 131, 0.6); padding:15px 0px;     background-color: #fff;">
            <center>
                <h2>2 BHK - Carpet Area (776 Sq.Ft - 847 Sq.Ft )</h2>
            </center>
            <div class="col-md-7" data-aos="zoom-in">
                <img src="./images/2bhk.png" class="img-fluid bhkimg" alt="2 BHK in Dombivli">
            </div>
            <div class="col-12 col-md-5 bhk" data-aos="zoom-in">
             

                <h3 style=" font-size:25px;  color:#03a9f4; ">
                    <b>
                        68 Lacs- 72 Lacs All Inclusive
                    </b>
                </h3>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg> Bigger Carpet

                </p>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Separate Pooja room


                </p>

                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Spacious Balconies

                </p>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Vastu Certified


                </p>


                <center> <a href="https://wa.me/9892544519?text=Hello,

I am interested to know more about APR Emerald.

Please share the project details and connect me on the same number" target="_blank" type="button" class="btn btn-success" style="padding: 3px 3rem;"><b>Contact Now </b> </a> </center>
            </div>

        </div>



        <div class="row mt-3" style="margin-top: 2rem;
    box-shadow: 0 0 30px rgba(114, 120, 131, 0.6); padding:15px 0px;     background-color: #fff;">
            <center>
                <h2>2.5 BHK - Carpet Area (916 Sq.Ft - 959 Sq.Ft )</h2>
            </center>
            <div class="col-md-7" data-aos="zoom-in">
                <img src="./images/2.5bhk.png" class="img-fluid bhkimg" alt="2.5 BHK ">
            </div>
            <div class="col-12 col-md-5 bhk" data-aos="zoom-in">

               
                <h3 style=" font-size:25px; color:#03a9f4; ">
                    <b>
                        76.50 Lacs - 82 Lacs All Inclusive

                    </b>
</h3>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg> Bigger Carpet

                </p>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Separate Pooja room

                </p>

                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Spacious Balconies

                </p>
                <p>

                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color: #009fff;" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                    </svg>
                    Vastu Certified

                </p>


                <center> <a href="https://wa.me/9892544519?text=Hello,

I am interested to know more about APR Emerald.

Please share the project details and connect me on the same number" target="_blank" type="button" class="btn btn-success" style="padding: 3px 3rem;"><b>Contact Now </b> </a> </center>
            </div>

        </div>
    </div>








</div>
</div>
<?php
include "./include/footer.php";

?>