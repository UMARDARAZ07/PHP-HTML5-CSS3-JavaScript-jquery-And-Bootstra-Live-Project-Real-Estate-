<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require "./PHPMailer-master/PHPMailer-master/src/Exception.php";
require "./PHPMailer-master/PHPMailer-master/src/PHPMailer.php";
require "./PHPMailer-master/PHPMailer-master/src/SMTP.php";


if(isset($_POST['Enquiry'])){
    $name =$_POST['name'];
   $email=$_POST['email'];
   $number=$_POST['number'];
   $Message=$_POST['Message'];
 

        


$mail = new PHPMailer(); $mail->IsSMTP(); $mail->Mailer = "smtp";




$mail->SMTPDebug  = 1;  
$mail->SMTPAuth   = TRUE;
$mail->SMTPSecure = "tls";
$mail->Port       = 587;
$mail->Host       = "smtp.gmail.com";
$mail->Username   = "ayushiapremerald@gmail.com";
$mail->Password   = "adqjnuailnedxwdx";


$mail->IsHTML(true);
$mail->AddAddress("ayushiapremerald@gmail.com");
$mail->SetFrom($email);
// $mail->AddReplyTo();
// $mail->AddCC();
$mail->Subject = $name;
$content ="Mobile Number :".$number ."<br>"."Intersted in :". $Message;



$mail->MsgHTML($content); 
if(!$mail->Send()) {
    header("location: ./fail.php");
  var_dump($mail);
} else {
 header("location: ./sus.php");
}


}
?>


