<?php
include "./include/header.php";

?>

<br>
<br>
<br>

<br>
<br>

<br>

<style>
  @media (max-width:540px){
    #about{
      padding: 0px;
    }

    #services{
      padding: 0px;
    }
  }
</style>
<!-- Get Touch Section -->
<div id="get-touch">
  <div class="container">
    <div class="row">
      <div class="col-12 col-md-offset-1 " data-aos="fade-down">
      <br>
<br>
        <center class="mt-5">
        <h1 class="mt-5" style="    font-size: 24px;">About Apr Reality</h1>
        </center>
        <center>
          <p>
            APR Realty, started in 2017 by indian enterprenuers Prashant Jadhav & Ajit Munde. The group has spread its
            wings across Dombivli Real Estate and working on three residential projects, APR Emerald, Adishakti,
            Emerald Pacific. The group is working towards governments mission of "HOUSING FOR ALL"
          </p>
        </center>
        <center>
          <p>
            At Realty, we understand that finding the perfect property or selling your valuable asset can be a
            significant decision in your life. With our unwavering commitment to excellence and a deep understanding
            of the real estate market, we strive to make this journey seamless and rewarding for you.
          </p>
        </center>
      </div>
      <!-- <div class="col-xs-12 col-md-4 text-center"><a href="#contact" class="btn btn-custom btn-lg page-scroll">Free Estimate</a></div> -->
    </div>
  </div>
</div>
<!-- About Section -->
<div id="about" style="background-color: #1f386e;">
  <center>
    <h3 style="color: #fff;"> Projects Proceeding :</h3>
  </center>
  <div class="container">
    <div class="d-flex flex-wrap" data-aos="fade-up">
      <div class=" col-md-6 col-12 d-flex justify-content-center pt-3" style="height: auto;" >

        <!-- <h2>Carousel Example</h2> -->
        <div id="myCarousel" class="carousel slide " data-ride="carousel">
          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

          <!-- Wrapper for slides -->
          <div class="carousel-inner">

            <div class="item active">
              <img src="./images/apre.jpg" alt="Ready Possession property in Dombivli" style="width:100%; height: 400px;">
              <div class="carousel-caption">

                <p>
                  <b>
                    APR Emerald
                  </b>
                </p>
              </div>
            </div>

            <div class="item">
              <img src="./images/adishakti.jpg" alt="Adhishakti  project" style="width:100%; height: 400px;">
              <div class="carousel-caption">

                <p>
                  <b>
                    Adishakti
                  </b>
                </p>
              </div>

            </div>

            <div class="item">
              <img src="./images/emerald.jpg" alt="Under Construction Property in Dombivl" style="width:100%; height:400px;">
              <div class="carousel-caption">

                <p>
                  <b>
                    Emerald Pacific
                  </b>
                </p>
              </div>
            </div>

          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>

      <div class="col-md-6 col-12" data-aos="fade-up">

        <div class="about-text ">
          <p style="color: #fff;">
            <b>
              APR Emerald :
            </b> APR Emerald is flagship project by APR Realty, Located in Shankara Nagar, Dombivli East. The project is spread across 2.5 Acres of landparcel and offers world class amenities with club house, garden, kids play area, gym etc.
          </p>

          <p style="color: #fff;">
            <b>
              Adishakti :
            </b> Adishakti is located on Manpada road Nr, Dombivli Railway Station. Loacted next to Jain Temple. The project comprises of commercial space, 1 & 2 bed residences.

          </p>

          <p style="color: #fff;">
            <b>
              Emerald Pacific :
            </b> Emerald Pacific is a redevelopment project by APR Realty. The project is located in Gandhinagar, Dombivli East. The project comprises of commercial space, 1 & 2 bed residences.
          </p>



          <!-- <center><button class="btn btn-primary">Book Know</button></center> -->
        </div>


      </div>

    </div>


    


<br>
<br>




  </div>
</div>


<?php
include "./include/footer.php";

?>